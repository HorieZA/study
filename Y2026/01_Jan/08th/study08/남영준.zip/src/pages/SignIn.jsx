import {useState,useEffect} from "react"
import {useParams,useNavigate} from "react-router"

const SignIn = () => {
  const navigate = useNavigate()
  const close = () => navigate("/")
  
  return (
    <>
      <h1 className="text-center bg-success text-dark bg-opacity-50">SignIn</h1>
      <form>
        <div className="mb-3 mt-3">
          <label htmlFor="email">Email:</label>
          <input type="email" className="form-control" id="email" placeholder="Enter email" name="email" required />
        </div>
        <div className="mb-3">
          <label htmlFor="pwd">Password:</label>
          <input type="password" className="form-control" id="pwd" placeholder="Enter password" name="pswd" required />
        </div>
        <div className="d-flex">
          <div className="p-2 flex-fill d-grid">
            <button type="submit" className="btn btn-warning">SignIn</button>
          </div>
          <div className="p-2 flex-fill d-grid">
            <a href="/signUp" className="btn btn-primary">SignUp</a>
          </div>
          <div className="p-2 flex-fill d-grid">
            <button className="btn btn-danger" onClick={close}>Cancel</button>
          </div>
        </div>
      </form>
    </>
  )
}

export default SignIn