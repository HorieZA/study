import {useState,useEffect} from "react"
import {useParams,useNavigate} from "react-router"

const User = () => {
  const navigate = useNavigate()
  const params = useParams()
  const close = () => navigate("/")
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [accept, setAccept] = useState(0)
  const [inEdit, setInEdit] = useState(true)

  const onSubmit = e => {
    e.preventDefault()
    // inEdit가 false인 경우 리턴 하고 true이면 데이터를 저장
    if (!inEdit) return
    const data = { title, content, accept }
    console.log(data)
  }

  useEffect(() => {
    // 선언된 data.js 파일의 list 배열 N번째 인덱스의 객체를 data에 저장하여, 값이 없으면 목록으로 이동하고, 있으면 각 값에 각각 저장 
    const data = list[params.id]
    if (data === undefined) return close()
    setTitle(data?.title)
    setContent(data?.content)
    setAccept(data?.accept)
  }, [])

  return (
    <>
      <h1 className="text-center bg-success text-dark bg-opacity-50">User</h1>
      <img src="/images/img_avatar1.png" className="d-block mx-auto mt-3 profile-image" />
      <form>
        <div className="mb-3 mt-3">
          <label htmlFor="name">Name:</label>
          <input type="text" className="form-control" id="name" placeholder="Enter name" name="name" required readonly />
        </div>
        <div className="mb-3 mt-3">
          <label htmlFor="email">Email:</label>
          <input type="email" className="form-control" id="email" placeholder="Enter email" name="email" required readonly />
        </div>
        <div className="mb-3">
          <label htmlFor="pwd">Password:</label>
          <input type="password" className="form-control" id="pwd" placeholder="Enter password" name="pswd" required readonly />
        </div>
        <div className="mb-3">
          <label htmlFor="job">Job:</label>
          <input type="text" className="form-control" id="job" placeholder="Enter job" name="job" />
        </div>
        <div className="d-flex">
          <div className="p-2 flex-fill">
            <div className="form-check">
              <input type="radio" className="form-check-input" id="gender1" name="gender" value="1" checked />남성
              <label className="form-check-label" htmlFor="gender1"></label>
            </div>
          </div>
          <div className="p-2 flex-fill">
            <div className="form-check">
              <input type="radio" className="form-check-input" id="gender2" name="gender" value="2" />여성
              <label className="form-check-label" htmlFor="gender2"></label>
            </div>
          </div>
        </div>
        <div className="d-flex">
          <div className="p-2 flex-fill d-grid">
            <button type="submit" className="btn btn-success">Edit</button>
          </div>
          <div className="p-2 flex-fill d-grid">
            <button className="btn btn-danger" onClick={close}>Cancel</button>
          </div>
        </div>
      </form>
    </>
  )
}

export default User