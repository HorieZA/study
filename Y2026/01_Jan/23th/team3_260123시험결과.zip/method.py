from db import findOne, findAll, save

def empty():
  print("함수 정의가 되어 있지 않습니다.")

def userList(args):
  sql = """
        select 
          `no`, `name`, `email`, `pwd`, `gender`, `regDate`
        from team3.user
        where `delYn` = 0
        """
  list = findAll(sql)
  print("번호\t이름\t이메일\t비밀번호\t성별\t회원등록일")
  print("-"*80)
  for row in list:
    print(f"{row['no']}\t{row['name']}\t{row['email']}\t{row['gender']}\t{row['regDate']}")
  
def userAdd(args):
  sql = f"""
        insert into team3.user
          (`name`, `email`, `pwd`, `gender`)
        value
          ('{args.name}','{args.email}','{args.pwd}','{args.gender}')
        """
  save(sql)
  userList(None)

def userDetail(args):
  sql =f"""
        select 
          `no`, `name`, `email`, `pwd`, `gender`,`delYn`, `regDate`,`modDate`
        from team3.user
        where `no` = {args.no}
        """
  row = findOne(sql)
  print("번호\t이름\t이메일\t비밀번호\t성별\t탈퇴여부\t회원등록일\t회원수정일")
  print("-"*80)
  if row:
    print(f"{row['no']}\t{row['name']}\t{row['email']}\t{row['pwd']}\t{row['gender']}\t{row['delYn']}\t{row['regDate']}\t{row['modDate']}")
  else:
    None

def userEdit(args):
  sql=f"""
      update team3.user
      set
      `name`='{args.name}',`email`='{args.email}',`pwd`='{args.pwd}',`gender`='{args.gender}'
      where `no` = {args.no}
"""
  save(sql)
  userDetail(args)

def userDelete(args) :
  sql = f"""
        update team3.user
        set
          `delYn` = '{args.delYn}'
        where
          `no` = {args.no}
        """
  save(sql)
  userList(None)

def boardList(args) :
  sql = f"""
        select b.`no`, b.`title`, b.`regDate`, u.`name`
          from team3.board as b
        inner join team3.user as u
        on (b.`user_no` = u.`no`)
        where
          b.`delYn` = 0
        """
  list = findAll(sql)
  print(f"번호\t제목\t작성자\t작성일")
  print("-" * 80)
  for row in list :
    print(f"{row['no']}\t{row['title']}\t{row['name']}\t{row['regDate']}")

def boardAdd(args) :
  sql = f"""
        insert into team3.board
          (`title`, `cont`, `user_no`)
        value
          ('{args.title}', '{args.cont}', '{args.user_no}')
        """
  save(sql)
  boardList(None)

def boardDetail(args):
  sql = f"""
          SELECT b.`no`, b.`title`, b.`cont`, b.`modDate`, u.`name`
          FROM team3.board AS b
          INNER JOIN team3.user AS u
          ON (b.`user_no` = u.`no`)
          WHERE b.`no` = {args.no}
          """
  row = findOne(sql)
  print(f"번호\t제목\t내용\t작성자\t수정일")
  print(f"-"*80)
  if row :
    print(f"{row['no']}\t{row['title']}\t{row['cont']}\t{row['modDate']}\t{row['name']}")
  else:
    None

def boardEdit(args):
  sql = f"""
          UPDATE team3.board
          SET `title` = '{args.title}', `cont`='{args.cont}'
          WHERE `no` = {args.no}
          AND `user_no` = {args.user_no}
          """
  save(sql)
  boardDetail(args)

def boardDelete(args):
    sql = f"""
        update team3.board
        set
          `delYn` = '{args.delYn}'
        where
          `no` = {args.no}
        """
    save(sql)
    boardList(args)