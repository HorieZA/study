from db import findOne, findAll, save

def empty():
  print("함수 정의가 되어 있지 않습니다.")

