import { useState, useEffect } from "react"
import { useNavigate } from "react-router"
import { list } from "@/data.js"

const SignIn = () => {
  const navigate = useNavigate()
  const close = () => navigate("/")
  const [arrs, setArrs] = useState([])
  const [email, setEamil] = useState("")
  const [pwd, setPwd] = useState("")

  const onSubmit = e => {
    e.preventDefault()
    const data = { email, pwd }
    
    let login = list.find( i => i.email === data.email && i.pwd === data.pwd)
    
    if(login) {
      console.log(`${login.name}님 환영합니다.`)
    } else {
      console.log("로그인에 실패하였습니다.")
    }
    
    // filter를 이용한 로그인 방식 (단 name값을 불러올수 없음)
    // if(list.filter(row => row.email === data.email && row.pwd === data.pwd)) {
    //   const logs = list.filter(row => row.email === data.email && row.pwd === data.pwd)
    //   console.log(logs.name)
    //   console.log(`${logs}님 환영합니다.`)
    // } else {
    //   console.log("로그인에 실패하였습니다.")
    // }

    // some을 이용한 로그인 방식
    // let name = ""
    // const userFound = list.some(user => {
    //   if(user.email === data.email && user.pwd === data.pwd) {
    //     name = user.name
    //   } 
    //   return user.email === data.email && user.pwd === data.pwd
    // })

    // if (userFound) {
    //   console.log(`${name}님 환영합니다.`)
    //   return true;
    // } else {
    //   console.log("로그인에 실패하였습니다.")
    //   return false;
    // }
  }

  return (
    <>
      <h1 className="text-center bg-success text-dark bg-opacity-50">SignIn</h1>
      <form onSubmit={onSubmit}>
        <div className="mb-3 mt-3">
          <label htmlFor="email">Email:</label>
          <input type="email" className="form-control" id="email" placeholder="Enter email"
            name="email" required onChange={e => setEamil(e.target.value)} />
        </div>
        <div className="mb-3">
          <label htmlFor="pwd">Password:</label>
          <input type="password" className="form-control" id="pwd" placeholder="Enter password"
            name="pswd" required onChange={e => setPwd(e.target.value)} />
        </div>
        <div className="d-flex">
          <div className="p-2 flex-fill d-grid">
            <button type="submit" className="btn btn-warning">SignIn</button>
          </div>
          <div className="p-2 flex-fill d-grid">
            <a href="/signUp" className="btn btn-primary">SignUp</a>
          </div>
          <div className="p-2 flex-fill d-grid">
            <button className="btn btn-danger" onClick={close}>Cancel</button>
          </div>
        </div>
      </form>
    </>
  )
}

export default SignIn